from flask import Flask, request, jsonify
import openai

app = Flask(__name__)

# Set your OpenAI API key
openai.api_key = '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'

@app.route('/generate', methods=['POST'])
def generate_prompt():
    # Get input parameters from the request
    text = request.form.get('prompt', '')
   

    if not text:
        return jsonify({'error': 'text is required'})

    # Build the prompt with prompt engineering techniques
    prompt = build_prompt(text)

    # Call OpenAI API to generate output
    response = openai.ChatCompletion.create(
        model="gpt-4-1106-preview",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": prompt},
        ],
        max_tokens=400  # Adjust as needed
    )

    # Extract the generated text
    generated_output = response['choices'][0]['message']['content']
    print(generated_output)
    return jsonify({'generated_output': generated_output})

def build_prompt(text):
    """Constructs a well-engineered prompt based on inputs and conditions."""

    base_prompt = "Give me 5 points each containing 1 lines. Give it in news format. If the information is unknown, provide last updated answers. Add place for each point if possible. give the source or link for each.:"

    # Condition handling using conditional phrases
   
    prompt = f"{base_prompt} {text}"

    # Additional prompt engineering techniques (optional):
    # - Add examples or context for clarity
    # - Break down complex prompts into smaller steps
    # - Use specific instructions or formatting guidance

    return prompt

if __name__ == '__main__':
    app.run(host='0.0.0.0',port=6001)
