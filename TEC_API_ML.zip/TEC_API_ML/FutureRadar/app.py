from flask import Flask, render_template, request, jsonify
import pandas as pd

app = Flask(__name__)

def search_keyword(csv_path, keyword):
    # Read CSV file
    df = pd.read_csv(csv_path, encoding='ISO-8859-1')


    # Search for rows containing the provided keyword
    keyword_rows = df[df['Content'].str.contains(keyword, case=False)]

    # Create lists for content, title, and link
    content_list = keyword_rows['Content'].tolist()
    title_list = keyword_rows['Title'].tolist()
    link_list = keyword_rows['Link'].tolist()

    # Create JSON response
    response = {'content': content_list, 'title': title_list, 'link': link_list}

    return response

@app.route('/futureradar_search', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Get the keyword from the form data
        keyword = request.form['keyword']

        # Replace 'your_extracted_data.csv' with the actual path to your CSV file
        csv_path = 'webscraped_data.csv'

        # Search for the provided keyword in the CSV and get the results
        results = search_keyword(csv_path, keyword)

        # Return the results as JSON
        return jsonify(results)

    # Render the HTML template with the form
    return render_template('index.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=6000)
